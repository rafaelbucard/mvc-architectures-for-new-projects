
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meu CRUD</title>
</head>
<body>
    
</body>
</html>
<h1>Lista de Clientes</h1>
<hr/>