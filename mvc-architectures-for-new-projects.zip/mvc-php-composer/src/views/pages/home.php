<?php
    $render('header');
?>

<a href="<?=$base;?>/novo">Novo Usuário</a>