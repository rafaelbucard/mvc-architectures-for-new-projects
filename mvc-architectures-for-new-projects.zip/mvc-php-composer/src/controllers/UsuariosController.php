<?php
namespace src\controllers;

use \core\Controller;

class UsuariosController extends Controller {

    public function add() {
            echo 'ADD';
    }

}